"""
Store & Forward — inti dari klaim "tahan saat internet putus".

Event ditulis ke SQLite lokal **lebih dulu**, baru dikirim. Kalau link mati,
antrean menumpuk di disk site dan terkirim otomatis saat pulih. Tidak ada event
yang hilang hanya karena WAN putus 3 jam.

Yang dikirim ke atas: event + metadata + snapshot kecil. Tidak pernah video.
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

import requests

from .proto import Event, EventBatch, Heartbeat

_SCHEMA = """
CREATE TABLE IF NOT EXISTS spool (
    event_id   TEXT PRIMARY KEY,
    created_at REAL NOT NULL,
    attempts   INTEGER NOT NULL DEFAULT 0,
    payload    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_spool_created ON spool(created_at);
"""


class Spool:
    def __init__(self, db_path: str, max_rows: int = 50_000):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.max_rows = max_rows
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._conn.commit()

    def put(self, event: Event) -> None:
        with self._lock:
            self._conn.execute(
                "INSERT OR IGNORE INTO spool(event_id, created_at, payload) VALUES (?,?,?)",
                (event.event_id, time.time(), event.model_dump_json()),
            )
            self._conn.commit()
            self._trim()

    def _trim(self) -> None:
        n = self._conn.execute("SELECT COUNT(*) FROM spool").fetchone()[0]
        if n > self.max_rows:
            # Buang yang paling tua. Kalau link mati berhari-hari, event terbaru
            # lebih berharga daripada event minggu lalu.
            self._conn.execute(
                "DELETE FROM spool WHERE event_id IN "
                "(SELECT event_id FROM spool ORDER BY created_at ASC LIMIT ?)",
                (n - self.max_rows,),
            )
            self._conn.commit()

    def take(self, limit: int = 50) -> list[tuple[str, Event]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT event_id, payload FROM spool ORDER BY created_at ASC LIMIT ?", (limit,)
            ).fetchall()
        return [(r[0], Event(**json.loads(r[1]))) for r in rows]

    def ack(self, event_ids: list[str]) -> None:
        if not event_ids:
            return
        with self._lock:
            self._conn.executemany("DELETE FROM spool WHERE event_id=?", [(e,) for e in event_ids])
            self._conn.commit()

    def bump(self, event_ids: list[str]) -> None:
        with self._lock:
            self._conn.executemany(
                "UPDATE spool SET attempts=attempts+1 WHERE event_id=?", [(e,) for e in event_ids]
            )
            self._conn.commit()

    def pending(self) -> int:
        with self._lock:
            return self._conn.execute("SELECT COUNT(*) FROM spool").fetchone()[0]


class Forwarder:
    def __init__(self, spool: Spool, regional_url: str, api_key: str, engine_id: str, site_id: str, interval: float = 5.0):
        self.spool = spool
        self.url = regional_url.rstrip("/")
        self.api_key = api_key
        self.engine_id = engine_id
        self.site_id = site_id
        self.interval = interval

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.connected = False
        self.last_error = ""
        self.last_success_at = 0.0

    @property
    def _headers(self) -> dict:
        return {"X-API-Key": self.api_key, "Content-Type": "application/json"}

    def start(self, heartbeat_fn) -> None:
        self._heartbeat_fn = heartbeat_fn
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="forwarder", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _run(self) -> None:
        beat_every = 30.0
        last_beat = 0.0

        while not self._stop.is_set():
            if not self.url:
                self._stop.wait(self.interval)
                continue

            self._flush()
            if time.time() - last_beat >= beat_every:
                self._beat()
                last_beat = time.time()

            self._stop.wait(self.interval)

    def _flush(self) -> None:
        batch = self.spool.take(limit=50)
        if not batch:
            return
        ids = [b[0] for b in batch]
        payload = EventBatch(
            engine_id=self.engine_id, site_id=self.site_id, events=[b[1] for b in batch]
        )
        try:
            r = requests.post(
                f"{self.url}/api/ingest/events",
                data=payload.model_dump_json(),
                headers=self._headers,
                timeout=20,
            )
            if r.ok:
                self.spool.ack(ids)
                self.connected = True
                self.last_error = ""
                self.last_success_at = time.time()
            else:
                self.spool.bump(ids)
                self.connected = False
                self.last_error = f"HTTP {r.status_code}: {r.text[:160]}"
        except requests.RequestException as exc:
            self.spool.bump(ids)
            self.connected = False
            self.last_error = str(exc)[:200]

    def _beat(self) -> None:
        try:
            hb: Heartbeat = self._heartbeat_fn()
            r = requests.post(
                f"{self.url}/api/ingest/heartbeat",
                data=hb.model_dump_json(),
                headers=self._headers,
                timeout=12,
            )
            self.connected = r.ok
            if not r.ok:
                self.last_error = f"heartbeat HTTP {r.status_code}"
        except requests.RequestException as exc:
            self.connected = False
            self.last_error = str(exc)[:200]
