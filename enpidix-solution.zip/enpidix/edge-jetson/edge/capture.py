"""
Capture RTSP dengan decode hardware (NVDEC) di Jetson.

Ini inti perbaikan bottleneck #4: `cv2.VideoCapture(rtsp_url)` di Jetson akan
decode H.264/H.265 di CPU ARM — 3 kamera 1080p sudah cukup untuk menghabiskan
seluruh core Neoverse dan GPU-nya menganggur menunggu frame.

Pipeline yang dipakai:
    rtspsrc -> rtph26xdepay -> h26xparse -> nvv4l2decoder -> nvvidconv -> BGRx -> appsink

Frame terbaru disimpan dengan pola `frame_version` (bukan queue) supaya konsumen
lambat tidak menahan produsen — sama seperti refactor MJPEG di server pusat.
"""

from __future__ import annotations

import threading
import time

import cv2
import numpy as np


def _gst_pipeline(url: str, codec: str, width: int, height: int, latency: int = 200) -> str:
    depay = "rtph265depay ! h265parse" if codec == "h265" else "rtph264depay ! h264parse"
    return (
        f"rtspsrc location={url} latency={latency} protocols=tcp drop-on-latency=true ! "
        f"{depay} ! nvv4l2decoder enable-max-performance=1 ! "
        f"nvvidconv ! video/x-raw,format=BGRx,width={width},height={height} ! "
        f"videoconvert ! video/x-raw,format=BGR ! "
        f"appsink drop=true max-buffers=1 sync=false"
    )


class CameraStream:
    """Satu thread per kamera. Tidak ada lock global antar kamera."""

    def __init__(
        self,
        camera_id: str,
        url: str,
        decoder: str = "nvdec",
        codec: str = "h264",
        width: int = 704,
        height: int = 576,
    ):
        self.camera_id = camera_id
        self.url = url
        self.decoder = decoder
        self.codec = codec
        self.width = width
        self.height = height

        self._frame: np.ndarray | None = None
        self._version = 0
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

        self.online = False
        self.capture_fps = 0.0
        self.last_frame_at = 0.0
        self.active_decoder = decoder
        self.last_error = ""

    # ── lifecycle ────────────────────────────────────────────
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"cap-{self.camera_id}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=4)

    # ── konsumsi frame ───────────────────────────────────────
    def read(self, since_version: int = -1) -> tuple[np.ndarray | None, int]:
        """Kembalikan frame hanya kalau versinya lebih baru. Tanpa polling buta."""
        with self._lock:
            if self._frame is None or self._version == since_version:
                return None, self._version
            return self._frame.copy(), self._version

    @property
    def frame_age(self) -> float:
        return -1.0 if not self.last_frame_at else time.time() - self.last_frame_at

    # ── internal ─────────────────────────────────────────────
    def _open(self) -> cv2.VideoCapture | None:
        if self.decoder == "nvdec":
            pipe = _gst_pipeline(self.url, self.codec, self.width, self.height)
            cap = cv2.VideoCapture(pipe, cv2.CAP_GSTREAMER)
            if cap.isOpened():
                self.active_decoder = "nvdec"
                return cap
            # Codec bisa salah tebak — coba pasangannya sekali sebelum menyerah ke CPU.
            alt = "h265" if self.codec == "h264" else "h264"
            cap = cv2.VideoCapture(_gst_pipeline(self.url, alt, self.width, self.height), cv2.CAP_GSTREAMER)
            if cap.isOpened():
                self.codec = alt
                self.active_decoder = "nvdec"
                return cap
            self.last_error = "GStreamer/NVDEC gagal dibuka, jatuh ke decode CPU"

        cap = cv2.VideoCapture(self.url, cv2.CAP_FFMPEG)
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            self.active_decoder = "cpu"
            return cap
        return None

    def _run(self) -> None:
        backoff = 1.0
        frames, t0 = 0, time.time()

        while not self._stop.is_set():
            cap = self._open()
            if cap is None:
                self.online = False
                self.last_error = f"Tidak bisa konek ke {self.camera_id}"
                self._stop.wait(backoff)
                backoff = min(backoff * 2, 30.0)
                continue

            backoff = 1.0
            self.online = True
            self.last_error = ""

            while not self._stop.is_set():
                ok, frame = cap.read()
                if not ok or frame is None:
                    break
                if self.active_decoder == "cpu" and (frame.shape[1] != self.width):
                    frame = cv2.resize(frame, (self.width, self.height))

                with self._lock:
                    self._frame = frame
                    self._version += 1
                self.last_frame_at = time.time()

                frames += 1
                if frames >= 30:
                    now = time.time()
                    self.capture_fps = round(frames / max(now - t0, 1e-6), 1)
                    frames, t0 = 0, now

            cap.release()
            self.online = False
            self._stop.wait(2.0)
