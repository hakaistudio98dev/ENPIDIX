"""Telemetri khusus Jetson. `nvidia-smi` tidak ada di Tegra — pakai tegrastats/sysfs."""

from __future__ import annotations

import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

_state = {
    "gpu_pct": 0.0,
    "temp_c": 0.0,
    "power_w": 0.0,
    "ram_used_mb": 0.0,
    "ram_total_mb": 0.0,
}
_started = time.time()


def detect_model() -> str:
    """Baca nama modul dari device tree — sumber paling andal di Jetson."""
    for p in ("/proc/device-tree/model", "/sys/firmware/devicetree/base/model"):
        try:
            return Path(p).read_text(errors="ignore").strip("\x00").strip()
        except OSError:
            continue
    return "unknown"


def detect_jetpack() -> str:
    try:
        return Path("/etc/nv_tegra_release").read_text(errors="ignore").splitlines()[0].strip()
    except OSError:
        return ""


def _parse(line: str) -> None:
    if m := re.search(r"GR3D_FREQ (\d+)%", line):
        _state["gpu_pct"] = float(m.group(1))
    if m := re.search(r"RAM (\d+)/(\d+)MB", line):
        _state["ram_used_mb"], _state["ram_total_mb"] = float(m.group(1)), float(m.group(2))
    temps = [float(t) for t in re.findall(r"(?:CPU|GPU|SOC\d?|tj)@([\d.]+)C", line)]
    if temps:
        _state["temp_c"] = max(temps)
    if m := re.search(r"(?:VDD_IN|POM_5V_IN|VDD_GPU_SOC) (\d+)mW", line):
        _state["power_w"] = round(float(m.group(1)) / 1000, 1)


def start_monitor() -> None:
    if not shutil.which("tegrastats"):
        return

    def loop() -> None:
        try:
            proc = subprocess.Popen(
                ["tegrastats", "--interval", "2000"],
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
            )
            for line in proc.stdout:  # type: ignore[union-attr]
                _parse(line)
        except Exception:  # noqa: BLE001
            pass

    threading.Thread(target=loop, name="tegrastats", daemon=True).start()


def snapshot(record_dir: str = "/") -> dict:
    cpu = mem = disk = 0.0
    if psutil:
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent
        try:
            disk = psutil.disk_usage(record_dir).percent
        except OSError:
            disk = psutil.disk_usage("/").percent
    elif _state["ram_total_mb"]:
        mem = round(_state["ram_used_mb"] / _state["ram_total_mb"] * 100, 1)

    return {
        "cpu_pct": cpu,
        "mem_pct": mem,
        "disk_pct": disk,
        "gpu_pct": _state["gpu_pct"],
        "temp_c": _state["temp_c"],
        "power_w": _state["power_w"],
        "uptime_sec": round(time.time() - _started, 1),
        "model": detect_model(),
        "jetpack": detect_jetpack(),
    }
