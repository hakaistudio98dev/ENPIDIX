"""Pemuat konfigurasi edge — YAML di disk, hot-reload saat regional push config baru."""

from __future__ import annotations

import os
import shutil
import threading
from pathlib import Path

import yaml

from .proto import CameraConfig, EngineConfig

CONFIG_PATH = Path(os.environ.get("ENPIDIX_CONFIG", "/etc/enpidix/edge.yaml"))
_lock = threading.RLock()
_cache: EngineConfig | None = None


def _default() -> EngineConfig:
    return EngineConfig(
        engine_id=os.environ.get("ENPIDIX_ENGINE_ID", "jetson-unset"),
        site_id=os.environ.get("ENPIDIX_SITE_ID", "site-unset"),
    )


def load(force: bool = False) -> EngineConfig:
    global _cache
    with _lock:
        if _cache is not None and not force:
            return _cache
        if CONFIG_PATH.exists():
            raw = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
            _cache = EngineConfig(**raw)
        else:
            _cache = _default()
            save(_cache)
        return _cache


def save(cfg: EngineConfig) -> None:
    """Tulis atomik + backup .bak. Config rusak di site tanpa teknisi = truk mahal."""
    with _lock:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        if CONFIG_PATH.exists():
            shutil.copy2(CONFIG_PATH, CONFIG_PATH.with_suffix(".yaml.bak"))
        tmp = CONFIG_PATH.with_suffix(".yaml.tmp")
        tmp.write_text(
            yaml.safe_dump(cfg.model_dump(), sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        os.replace(tmp, CONFIG_PATH)
        globals()["_cache"] = cfg


def get_camera(cfg: EngineConfig, camera_id: str) -> CameraConfig | None:
    return next((c for c in cfg.cameras if c.camera_id == camera_id), None)


def upsert_camera(cam: CameraConfig) -> EngineConfig:
    cfg = load()
    others = [c for c in cfg.cameras if c.camera_id != cam.camera_id]
    if len(others) >= cfg.max_cameras:
        raise ValueError(
            f"Batas {cfg.max_cameras} kamera per engine tercapai. "
            "Naikkan max_cameras hanya kalau modul Jetson memang sanggup."
        )
    cfg.cameras = others + [cam]
    save(cfg)
    return cfg


def delete_camera(camera_id: str) -> EngineConfig:
    cfg = load()
    cfg.cameras = [c for c in cfg.cameras if c.camera_id != camera_id]
    save(cfg)
    return cfg


API_KEY = os.environ.get("ENPIDIX_EDGE_API_KEY", "")
REGIONAL_URL = os.environ.get("ENPIDIX_REGIONAL_URL", "")
REGIONAL_KEY = os.environ.get("ENPIDIX_REGIONAL_API_KEY", "")
SPOOL_DB = os.environ.get("ENPIDIX_SPOOL_DB", "/var/lib/enpidix/spool.db")
