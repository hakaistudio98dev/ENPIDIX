"""
Mesin inferensi edge.

Dua perbaikan pokok dibanding server pusat versi lama:

1. TIDAK ADA `yolo_lock` global. Tiap kamera punya worker sendiri. Di Jetson,
   satu GPU memang dibagi, tapi CUDA stream + batching driver jauh lebih efisien
   daripada mutex Python yang membuat inferensi kamera 2 menunggu kamera 1 selesai.
   Yang dibatasi adalah *jumlah worker* (semaphore), bukan urutannya.

2. Backend TensorRT (.engine) didahulukan. Model .pt di Jetson berjalan sekitar
   sepertiga kecepatan engine TensorRT INT8 yang sama.

Anti-flicker: status kejadian baru dilaporkan setelah `confirm_frames` frame
beruntun cocok — pola yang sama dipakai di deteksi api/asap dan okupansi parkir.
"""

from __future__ import annotations

import threading
import time
import uuid
from collections import defaultdict, deque
from typing import Callable

import numpy as np

from .proto import Event, utcnow

# Batas worker yang boleh menembak GPU bersamaan. Bukan serialisasi total:
# 3 worker paralel mengisi pipeline GPU jauh lebih baik daripada 1.
_GPU_SLOTS = threading.Semaphore(3)


class Detector:
    """Pembungkus model. Dimuat sekali, dipakai bersama semua worker."""

    def __init__(self, model_path: str, precision: str = "int8", imgsz: int = 640):
        self.model_path = model_path
        self.precision = precision
        self.imgsz = imgsz
        self.backend = "none"
        self.names: dict[int, str] = {}
        self._model = None
        self._load()

    def _load(self) -> None:
        try:
            from ultralytics import YOLO

            self._model = YOLO(self.model_path, task="detect")
            self.backend = "tensorrt" if self.model_path.endswith(".engine") else "pytorch"
            self.names = getattr(self._model, "names", {}) or {}
            if self.backend == "pytorch":
                print(
                    "[AI ⚠️] Model .pt terdeteksi. Di Jetson, export ke TensorRT dulu:\n"
                    f"        yolo export model={self.model_path} format=engine "
                    f"half=True device=0 imgsz={self.imgsz}"
                )
        except Exception as exc:  # noqa: BLE001
            self.backend = "none"
            print(f"[AI ❌] Gagal memuat model {self.model_path}: {exc}")

    def infer(self, frame: np.ndarray, conf: float, classes: list[str]) -> list[dict]:
        if self._model is None:
            return []
        with _GPU_SLOTS:
            res = self._model.predict(
                frame, conf=conf, imgsz=self.imgsz, verbose=False, device=0
            )[0]

        out: list[dict] = []
        h, w = frame.shape[:2]
        for box in res.boxes:
            cls_id = int(box.cls[0])
            name = self.names.get(cls_id, str(cls_id))
            if classes and name not in classes:
                continue
            x1, y1, x2, y2 = (float(v) for v in box.xyxy[0])
            out.append(
                {
                    "label": name,
                    "conf": float(box.conf[0]),
                    "bbox": [x1 / w, y1 / h, x2 / w, y2 / h],
                    "cx": (x1 + x2) / 2 / w,
                    "cy": (y1 + y2) / 2 / h,
                }
            )
        return out


class InferenceWorker:
    """Satu worker per kamera. Membaca frame terbaru, bukan mengantre frame lama."""

    def __init__(self, stream, cam_cfg, detector: Detector, emit: Callable[[Event], None], site_id: str, engine_id: str):
        self.stream = stream
        self.cfg = cam_cfg
        self.detector = detector
        self.emit = emit
        self.site_id = site_id
        self.engine_id = engine_id

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self.infer_fps = 0.0

        self._streak: dict[str, int] = defaultdict(int)
        self._reported: set[str] = set()
        self._side: dict[str, int] = {}
        self._recent = deque(maxlen=64)

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"ai-{self.cfg.camera_id}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=4)

    def update_config(self, cam_cfg) -> None:
        self.cfg = cam_cfg

    # ── loop ─────────────────────────────────────────────────
    def _run(self) -> None:
        last_version = -1
        counted, t0 = 0, time.time()

        while not self._stop.is_set():
            ai = self.cfg.ai
            if not ai.enabled or self.detector.backend == "none":
                self._stop.wait(1.0)
                continue

            interval = 1.0 / max(ai.infer_fps, 0.5)
            started = time.time()

            frame, version = self.stream.read(since_version=last_version)
            if frame is None:
                self._stop.wait(min(interval, 0.2))
                continue
            last_version = version

            try:
                dets = self.detector.infer(frame, ai.conf, ai.classes)
                self._evaluate(dets)
            except Exception as exc:  # noqa: BLE001
                self._emit_error(str(exc))
                self._stop.wait(2.0)
                continue

            counted += 1
            if counted >= 10:
                now = time.time()
                self.infer_fps = round(counted / max(now - t0, 1e-6), 1)
                counted, t0 = 0, now

            sleep_for = interval - (time.time() - started)
            if sleep_for > 0:
                self._stop.wait(sleep_for)

    # ── aturan kejadian ──────────────────────────────────────
    def _evaluate(self, dets: list[dict]) -> None:
        ai = self.cfg.ai
        seen = {d["label"] for d in dets}

        for label in list(self._streak.keys() | seen):
            if label in seen:
                self._streak[label] += 1
            else:
                self._streak[label] = 0
                self._reported.discard(label)

            # Anti-flicker: laporkan sekali saat streak menembus ambang, jangan tiap frame.
            if self._streak[label] >= ai.confirm_frames and label not in self._reported:
                self._reported.add(label)
                best = max((d for d in dets if d["label"] == label), key=lambda d: d["conf"], default=None)
                if best:
                    self._push("object_detected", label, best["conf"], best["bbox"])

        if ai.count_shape == "line":
            self._check_line(dets)

    def _check_line(self, dets: list[dict]) -> None:
        x1, y1, x2, y2 = self.cfg.ai.count_line
        for i, d in enumerate(dets):
            key = f"{d['label']}:{i}"
            side = 1 if ((x2 - x1) * (d["cy"] - y1) - (y2 - y1) * (d["cx"] - x1)) > 0 else -1
            prev = self._side.get(key)
            if prev is not None and prev != side:
                self._push(
                    "line_crossing",
                    d["label"],
                    d["conf"],
                    d["bbox"],
                    meta={"direction": "masuk" if side > 0 else "keluar"},
                )
            self._side[key] = side

    def _push(self, kind: str, label: str, conf: float, bbox, meta: dict | None = None) -> None:
        self.emit(
            Event(
                event_id=str(uuid.uuid4()),
                site_id=self.site_id,
                engine_id=self.engine_id,
                camera_id=self.cfg.camera_id,
                kind=kind,  # type: ignore[arg-type]
                label=label,
                confidence=round(conf, 3),
                ts=utcnow(),
                bbox=[round(v, 4) for v in bbox] if bbox else None,
                meta=meta or {},
            )
        )

    def _emit_error(self, msg: str) -> None:
        now = time.time()
        # Jangan banjiri regional kalau GPU error berulang tiap detik.
        if self._recent and now - self._recent[-1] < 60:
            return
        self._recent.append(now)
        self._push("engine_error", msg[:200], 0.0, None)
