"""
Perekam lokal — FFmpeg **stream copy**, bukan re-encode.

Bottleneck #1 dari audit: `-c:v libx264` memaksa Jetson men-decode lalu
meng-encode ulang stream yang sudah H.264/H.265. Untuk arsip CCTV itu murni
pemborosan: kualitas turun, CPU/GPU habis, dan hasilnya tidak lebih kecil
secara berarti.

`-c copy` menyalin paket apa adanya. Beban CPU praktis nol, dan ini yang
membuat satu Jetson sanggup merekam 6 kamera sambil tetap menjalankan YOLO.
"""

from __future__ import annotations

import shutil
import subprocess
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path


class Recorder:
    def __init__(self, camera_id: str, url: str, out_dir: str, segment_sec: int = 600, retention_days: int = 7):
        self.camera_id = camera_id
        self.url = url
        self.dir = Path(out_dir) / camera_id
        self.segment_sec = segment_sec
        self.retention_days = retention_days

        self._proc: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.running = False
        self.last_error = ""

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        if not shutil.which("ffmpeg"):
            self.last_error = "ffmpeg tidak ditemukan di PATH"
            return
        self.dir.mkdir(parents=True, exist_ok=True)
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name=f"rec-{self.camera_id}", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=6)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        self.running = False

    def _cmd(self) -> list[str]:
        pattern = str(self.dir / f"{self.camera_id}_%Y%m%d_%H%M%S.mp4")
        return [
            "ffmpeg", "-hide_banner", "-loglevel", "error",
            "-rtsp_transport", "tcp",
            "-use_wallclock_as_timestamps", "1",
            "-i", self.url,
            "-c", "copy",                 # ← inti perbaikan: TIDAK ada re-encode
            "-an",
            "-f", "segment",
            "-segment_time", str(self.segment_sec),
            "-segment_format", "mp4",
            "-segment_atclocktime", "1",
            "-reset_timestamps", "1",
            "-strftime", "1",
            "-movflags", "+faststart",
            pattern,
        ]

    def _run(self) -> None:
        backoff = 2.0
        last_purge = 0.0

        while not self._stop.is_set():
            try:
                self._proc = subprocess.Popen(
                    self._cmd(), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE
                )
                self.running = True
                while not self._stop.is_set() and self._proc.poll() is None:
                    if time.time() - last_purge > 3600:
                        self._purge()
                        last_purge = time.time()
                    self._stop.wait(5)

                if self._proc.poll() not in (0, None):
                    err = (self._proc.stderr.read() or b"").decode(errors="ignore")
                    self.last_error = err[-300:]
            except Exception as exc:  # noqa: BLE001
                self.last_error = str(exc)

            self.running = False
            if self._stop.is_set():
                break
            self._stop.wait(backoff)
            backoff = min(backoff * 2, 60.0)

    def _purge(self) -> None:
        """Retensi edge. Tanpa ini disk site penuh dalam hitungan minggu."""
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        for f in self.dir.glob("*.mp4"):
            try:
                if datetime.fromtimestamp(f.stat().st_mtime) < cutoff:
                    f.unlink()
            except OSError:
                pass
