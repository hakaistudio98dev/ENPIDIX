"""
ENPIDIX Edge — AI Engine (NVIDIA Jetson)
========================================
Tier 1. Berjalan di setiap site. Bertugas:
  • decode RTSP via NVDEC
  • inferensi YOLO/TensorRT per kamera
  • rekam lokal dengan stream copy
  • simpan event lokal dan kirim ke regional saat link tersedia
  • melayani MJPEG hanya saat ada yang menonton (on-demand)

Jalankan:
    ENPIDIX_ENGINE_ID=jetson-bgr-001 \\
    ENPIDIX_SITE_ID=site-bgr-001 \\
    ENPIDIX_EDGE_API_KEY=rahasia \\
    ENPIDIX_REGIONAL_URL=http://10.10.0.5:8200 \\
    ENPIDIX_REGIONAL_API_KEY=rahasia-regional \\
    uvicorn edge_main:app --host 0.0.0.0 --port 8100
"""

from __future__ import annotations

import asyncio
import base64
import threading
import time
from contextlib import asynccontextmanager

import cv2
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse

from edge import config as cfgmod
from edge import system
from edge.capture import CameraStream
from edge.forwarder import Forwarder, Spool
from edge.inference import Detector, InferenceWorker
from edge.proto import CameraConfig, Event, EngineConfig, Heartbeat, CameraStat, utcnow
from edge.recorder import Recorder

# ── state runtime ────────────────────────────────────────────
streams: dict[str, CameraStream] = {}
workers: dict[str, InferenceWorker] = {}
recorders: dict[str, Recorder] = {}
viewers: dict[str, int] = {}          # jumlah penonton MJPEG per kamera
detector: Detector | None = None
spool: Spool | None = None
forwarder: Forwarder | None = None
_lock = threading.RLock()


def require_key(x_api_key: str = Header(default="")) -> None:
    if cfgmod.API_KEY and x_api_key != cfgmod.API_KEY:
        raise HTTPException(401, "API key tidak valid")


# ── orkestrasi kamera ────────────────────────────────────────
def _emit(event: Event) -> None:
    if spool:
        spool.put(event)


def apply_camera(cam: CameraConfig, cfg: EngineConfig) -> None:
    """Idempoten: aman dipanggil ulang setiap kali config berubah."""
    with _lock:
        cid = cam.camera_id
        ai_url = cam.sub_url or cam.main_url

        if not cam.enabled:
            teardown_camera(cid)
            return

        st = streams.get(cid)
        if st is None or st.url != ai_url:
            if st:
                st.stop()
            st = CameraStream(cid, ai_url, decoder=cfg.decoder)
            streams[cid] = st
            st.start()

        w = workers.get(cid)
        if w is None:
            w = InferenceWorker(st, cam, detector, _emit, cfg.site_id, cfg.engine_id)
            workers[cid] = w
            w.start()
        else:
            w.stream = st
            w.update_config(cam)

        rec = recorders.get(cid)
        if cam.record:
            if rec is None or rec.url != cam.main_url:
                if rec:
                    rec.stop()
                rec = Recorder(cid, cam.main_url, cfg.record_dir, cfg.record_segment_sec, cfg.retention_days)
                recorders[cid] = rec
                rec.start()
        elif rec:
            rec.stop()
            recorders.pop(cid, None)


def teardown_camera(cid: str) -> None:
    with _lock:
        for pool in (workers, recorders, streams):
            obj = pool.pop(cid, None)
            if obj:
                obj.stop()


def reload_all() -> EngineConfig:
    cfg = cfgmod.load(force=True)
    live = {c.camera_id for c in cfg.cameras}
    for cid in list(streams.keys() | workers.keys() | recorders.keys()):
        if cid not in live:
            teardown_camera(cid)
    for cam in cfg.cameras:
        apply_camera(cam, cfg)
    return cfg


def build_heartbeat() -> Heartbeat:
    cfg = cfgmod.load()
    sysinfo = system.snapshot(cfg.record_dir)
    cams = []
    for cam in cfg.cameras:
        st, w, rec = streams.get(cam.camera_id), workers.get(cam.camera_id), recorders.get(cam.camera_id)
        cams.append(
            CameraStat(
                camera_id=cam.camera_id,
                name=cam.name,
                online=bool(st and st.online),
                ai_enabled=cam.ai.enabled,
                capture_fps=st.capture_fps if st else 0.0,
                infer_fps=w.infer_fps if w else 0.0,
                last_frame_age_sec=round(st.frame_age, 1) if st else -1.0,
                recording=bool(rec and rec.running),
            )
        )
    any_stream = next(iter(streams.values()), None)
    return Heartbeat(
        engine_id=cfg.engine_id,
        site_id=cfg.site_id,
        model=sysinfo["model"],
        jetpack=sysinfo["jetpack"],
        uptime_sec=sysinfo["uptime_sec"],
        cpu_pct=sysinfo["cpu_pct"],
        mem_pct=sysinfo["mem_pct"],
        disk_pct=sysinfo["disk_pct"],
        gpu_pct=sysinfo["gpu_pct"],
        temp_c=sysinfo["temp_c"],
        power_w=sysinfo["power_w"],
        engine_backend=detector.backend if detector else "none",
        decoder=any_stream.active_decoder if any_stream else cfg.decoder,
        spool_pending=spool.pending() if spool else 0,
        cameras=cams,
    )


# ── lifecycle ────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global detector, spool, forwarder

    cfg = cfgmod.load()
    system.start_monitor()
    detector = Detector(cfg.model_path, cfg.precision)
    spool = Spool(cfgmod.SPOOL_DB)

    forwarder = Forwarder(
        spool, cfgmod.REGIONAL_URL, cfgmod.REGIONAL_KEY,
        cfg.engine_id, cfg.site_id, cfg.forward_interval_sec,
    )
    forwarder.start(build_heartbeat)

    reload_all()
    _emit(Event(
        event_id=f"boot-{int(time.time())}", site_id=cfg.site_id, engine_id=cfg.engine_id,
        camera_id="-", kind="engine_started", label=system.detect_model(), ts=utcnow(),
    ))
    print(f"[EDGE ✅] {cfg.engine_id} @ {cfg.site_id} — backend={detector.backend} decoder={cfg.decoder}")

    yield

    if forwarder:
        forwarder.stop()
    for cid in list(streams.keys()):
        teardown_camera(cid)


app = FastAPI(title="ENPIDIX Edge AI Engine", version="1.0", lifespan=lifespan)


# ── endpoint ─────────────────────────────────────────────────
@app.get("/api/health")
def health():
    """Dipanggil regional tiap 30 detik. Sengaja tanpa API key agar mudah dimonitor NOC."""
    hb = build_heartbeat()
    return {
        **hb.model_dump(),
        "forwarder": {
            "connected": forwarder.connected if forwarder else False,
            "last_error": forwarder.last_error if forwarder else "",
            "regional_url": cfgmod.REGIONAL_URL or "(belum diset)",
        },
    }


@app.get("/api/config", dependencies=[Depends(require_key)])
def get_config() -> EngineConfig:
    return cfgmod.load()


@app.put("/api/config", dependencies=[Depends(require_key)])
def put_config(cfg: EngineConfig):
    """Regional push konfigurasi engine. Ganti model = muat ulang detector."""
    global detector
    old = cfgmod.load()
    cfgmod.save(cfg)
    if cfg.model_path != old.model_path or cfg.precision != old.precision:
        detector = Detector(cfg.model_path, cfg.precision)
        for w in workers.values():
            w.detector = detector
    reload_all()
    return {"status": "ok", "backend": detector.backend if detector else "none"}


@app.get("/api/cameras", dependencies=[Depends(require_key)])
def list_cameras():
    cfg = cfgmod.load()
    return [
        {
            **cam.model_dump(),
            "runtime": {
                "online": bool(streams.get(cam.camera_id) and streams[cam.camera_id].online),
                "decoder": streams[cam.camera_id].active_decoder if cam.camera_id in streams else "-",
                "capture_fps": streams[cam.camera_id].capture_fps if cam.camera_id in streams else 0,
                "infer_fps": workers[cam.camera_id].infer_fps if cam.camera_id in workers else 0,
                "recording": bool(recorders.get(cam.camera_id) and recorders[cam.camera_id].running),
                "viewers": viewers.get(cam.camera_id, 0),
                "error": streams[cam.camera_id].last_error if cam.camera_id in streams else "",
            },
        }
        for cam in cfg.cameras
    ]


@app.post("/api/cameras", dependencies=[Depends(require_key)])
def upsert_camera(cam: CameraConfig):
    try:
        cfg = cfgmod.upsert_camera(cam)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    apply_camera(cam, cfg)
    return {"status": "ok", "camera_id": cam.camera_id}


@app.delete("/api/cameras/{camera_id}", dependencies=[Depends(require_key)])
def remove_camera(camera_id: str):
    cfgmod.delete_camera(camera_id)
    teardown_camera(camera_id)
    return {"status": "ok"}


@app.get("/api/snapshot/{camera_id}", dependencies=[Depends(require_key)])
def snapshot(camera_id: str):
    st = streams.get(camera_id)
    if not st:
        raise HTTPException(404, "Kamera tidak aktif")
    frame, _ = st.read(since_version=-1)
    if frame is None:
        raise HTTPException(503, "Belum ada frame")
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
    if not ok:
        raise HTTPException(500, "Encode gagal")
    return {"camera_id": camera_id, "ts": utcnow(), "jpeg_b64": base64.b64encode(buf).decode()}


@app.get("/api/stream/{camera_id}")
def stream(camera_id: str, x_api_key: str = Header(default="")):
    """
    MJPEG on-demand. Generator hanya bangun saat `frame_version` berubah —
    tidak ada polling buta yang membakar CPU saat kamera diam.
    """
    if cfgmod.API_KEY and x_api_key != cfgmod.API_KEY:
        raise HTTPException(401, "API key tidak valid")
    st = streams.get(camera_id)
    if not st:
        raise HTTPException(404, "Kamera tidak aktif")

    def gen():
        viewers[camera_id] = viewers.get(camera_id, 0) + 1
        last = -1
        try:
            while True:
                frame, version = st.read(since_version=last)
                if frame is None:
                    time.sleep(0.02)
                    continue
                last = version
                ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
                if ok:
                    yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buf.tobytes() + b"\r\n"
        finally:
            viewers[camera_id] = max(0, viewers.get(camera_id, 1) - 1)

    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


@app.post("/api/engine/reload", dependencies=[Depends(require_key)])
def reload_engine():
    cfg = reload_all()
    return {"status": "ok", "cameras": len(cfg.cameras)}
