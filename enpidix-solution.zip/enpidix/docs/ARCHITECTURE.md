# ENPIDIX VMS — Arsitektur 3 Tier

Repo ini berisi tiga komponen terpisah yang membentuk satu sistem:

```
client-monitor/     Tier 3 — dashboard operator (HTML tunggal, tanpa build)
regional-server/    Tier 2 — pengumpul event & proxy, 1 instance per wilayah
edge-jetson/        Tier 1 — AI engine di setiap site (NVIDIA Jetson)
common/             Kontrak data bersama (Pydantic)
```

## Prinsip yang mengikat seluruh desain

**Video tidak naik ke atas.** Yang mengalir dari site ke regional hanyalah event,
metadata, snapshot kecil, dan heartbeat — sekitar 0,4 Mbps per site. Menarik
375 stream RTSP ke satu regional butuh ~1,9 Gbps terus-menerus; dengan pola ini
cukup ~50 Mbps. Video penuh hanya ditarik lewat endpoint proxy saat operator
benar-benar membuka live view, dan berhenti begitu tab ditutup.

**Client tidak pernah menyentuh Jetson.** Dashboard hanya tahu alamat regional
server. Semua konfigurasi AI Engine dan kamera dikirim lewat
`/api/engines/{id}/edge/{path}` yang meneruskan ke Jetson. Jetson boleh berada
di jaringan site tertutup atau di balik VPN tanpa perlu diekspos ke internet.

**Registry ada di server, bukan di browser.** Daftar AI Engine disimpan di
regional server sehingga semua operator melihat inventaris yang sama. Yang
disimpan lokal di browser hanya daftar alamat regional server (bisa
di-export/import JSON untuk disebar ke operator lain).

---

## Alur data

```
Kamera ──RTSP──▶ Jetson (NVDEC → YOLO/TensorRT → SQLite spool)
                   │
                   ├── push  event + heartbeat ──▶ Regional  (terus-menerus, ringan)
                   └── serve MJPEG on-demand   ◀── Regional  (hanya saat ditonton)
                                                     │
                                    Dashboard ◀──────┘
```

---

## Menjalankan

### 1. Regional server

```bash
cd regional-server
pip install -r requirements.txt
cp regional.env.example /etc/enpidix/regional.env   # isi API key
set -a && source /etc/enpidix/regional.env && set +a
uvicorn regional_main:app --host 0.0.0.0 --port 8200
```

### 2. Edge Jetson

OpenCV bawaan JetPack **wajib** dipakai — versi PyPI tidak punya GStreamer,
dan tanpa GStreamer tidak ada NVDEC.

```bash
sudo apt install python3-opencv ffmpeg
python3 -m venv /opt/enpidix/venv --system-site-packages
/opt/enpidix/venv/bin/pip install -r requirements.txt

# Verifikasi NVDEC tersedia — kalau kosong, decode akan jatuh ke CPU
python3 -c "import cv2;print(cv2.getBuildInformation())" | grep -i gstreamer

# Export model ke TensorRT sebelum produksi
yolo export model=yolov8s.pt format=engine half=True device=0 imgsz=640

cp config.example.yaml /etc/enpidix/edge.yaml
cp edge.env.example /etc/enpidix/edge.env
sudo cp systemd/enpidix-edge.service /etc/systemd/system/
sudo systemctl enable --now enpidix-edge
```

### 3. Dashboard

`client-monitor/dashboard.html` adalah file tunggal tanpa dependensi build.
Buka langsung, atau sajikan lewat nginx/`python3 -m http.server`.

Langkah pertama: tab **Server Regional** → tambahkan alamat + Client API Key.
Lalu tab **AI Engine** → daftarkan Jetson (Engine ID, Site ID, host, Edge API Key)
→ tombol **Kelola** untuk mengatur model, decoder, dan kamera.

---

## Empat bottleneck yang sudah ditangani di kode ini

Audit sebelumnya menemukan empat hal yang membuat hardware sekuat apa pun
tetap tersendat. Semuanya sudah tertutup di repo ini:

| Masalah lama | Penanganan | Berkas |
|---|---|---|
| FFmpeg re-encode `libx264` | `-c copy`, segmentasi, purge retensi | `edge/recorder.py` |
| AI memakai main stream | `sub_url` terpisah, ditolak di UI kalau kosong | `edge/config.py`, dashboard |
| `yolo_lock` global menyerialkan inferensi | Worker per kamera + semaphore 3 slot GPU | `edge/inference.py` |
| Decode software via OpenCV | GStreamer `nvv4l2decoder` (NVDEC), fallback CPU | `edge/capture.py` |

Ditambah dua hal yang muncul saat naik ke skala 625 site:

- **Store & forward** — event masuk SQLite lokal dulu, terkirim otomatis saat
  link pulih. Antrean dibatasi 50.000 baris; saat penuh, event tertua dibuang
  karena event terbaru lebih berharga.
- **Dedupe berbasis `event_id`** — edge aman mengirim ulang batch yang gagal
  di-ACK tanpa menghasilkan duplikat di regional.

---

## Catatan skala

SQLite cukup untuk satu regional saat uji coba. Untuk 125 site × 3 kamera
produksi, pindah ke PostgreSQL + TimescaleDB: tabel `events` akan tumbuh
jutaan baris per bulan dan SQLite mulai tersendat di sekitar 5–10 juta baris.
Struktur query di `regional/db.py` sengaja dibuat lugas agar migrasinya mudah.

Batas `max_cameras` per engine default 6. Angka itu realistis untuk Orin NX 16GB
dengan YOLOv8s INT8 pada 5 FPS inferensi. Menaikkannya di Orin Nano 8GB akan
membuat inferensi tersendat — modul itu juga tidak punya NVENC sama sekali.
