/* ═══════════════════════════════════════════════════════════════
   ENPIDIX FLEET — Tier 2 & 3
   Dibungkus IIFE: tidak ada satu pun variabel yang bocor ke scope
   global, jadi tidak mungkin bentrok dengan kode dashboard lama.
   ═══════════════════════════════════════════════════════════════ */
(function(){
"use strict";

const LS = "enpidix.servers.v1";
const q  = s => document.querySelector(s);
const qa = s => Array.from(document.querySelectorAll(s));
const esc = s => String(s ?? "").replace(/[&<>"']/g, c =>
  ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

let servers = [];
let S = { engines:{}, overview:{}, editSrv:-1, editEng:null };

try { servers = JSON.parse(localStorage.getItem(LS) || "[]"); } catch(e){ servers = []; }
const saveServers = () => localStorage.setItem(LS, JSON.stringify(servers));
const srvById = id => servers.find(s => s.id === id);

async function call(srv, path, opts={}){
  const res = await fetch(srv.url.replace(/\/$/,"") + path, {
    ...opts, headers:{ "Content-Type":"application/json", "X-API-Key": srv.key || "", ...(opts.headers||{}) }
  });
  if(!res.ok){
    let d = "HTTP " + res.status;
    try { const j = await res.json(); d = j.detail || d; } catch(e){}
    throw new Error(d);
  }
  return res.json();
}
function msg(sel, ok, text){
  const el = q(sel); if(!el) return;
  el.textContent = text;
  el.style.color = ok ? "#2FE6A6" : "#FF4D5E";
  el.style.display = "block";
  setTimeout(()=>{ el.style.display = "none"; }, 6000);
}
const fmtTime = iso => { const d = new Date(iso);
  return isNaN(d) ? "-" : d.toLocaleString("id-ID",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit",second:"2-digit"}); };
const ago = s => { if(!s) return "-"; const d = Math.floor(Date.now()/1000 - s);
  return d<60 ? d+" dtk lalu" : d<3600 ? Math.floor(d/60)+" mnt lalu" : Math.floor(d/3600)+" jam lalu"; };

/* ───── Saklar lingkup: Site Ini ↔ Fleet ───── */
qa("#scopeSeg button").forEach(b => b.addEventListener("click", () => {
  qa("#scopeSeg button").forEach(x => x.classList.remove("active"));
  b.classList.add("active");
  const fleet = b.dataset.scope === "fleet";
  document.body.classList.toggle("scope-fleet", fleet);
  q("#fleetView").classList.toggle("active", fleet);
  if(fleet) refresh();
}));

qa(".fleet-tab").forEach(t => t.addEventListener("click", () => {
  qa(".fleet-tab").forEach(x => x.classList.remove("active"));
  qa(".fleet-pane").forEach(x => x.classList.remove("active"));
  t.classList.add("active");
  q("#fv-" + t.dataset.fv).classList.add("active");
  if(t.dataset.fv === "events") loadEvents();
}));
qa("[data-fclose]").forEach(b => b.addEventListener("click", () => b.closest(".fleet-ov").classList.remove("active")));
qa(".fleet-ov").forEach(o => o.addEventListener("click", e => { if(e.target === o) o.classList.remove("active"); }));

/* ───── Polling utama ───── */
async function refresh(){
  const res = await Promise.allSettled(servers.map(async srv => {
    const t0 = performance.now();
    const overview = await call(srv, "/api/overview");
    const engines  = await call(srv, "/api/engines");
    return { overview, engines, latency: Math.round(performance.now()-t0) };
  }));
  S.engines = {}; S.overview = {};
  res.forEach((r,i) => {
    const srv = servers[i];
    if(r.status === "fulfilled"){
      S.overview[srv.id] = {...r.value.overview, _ok:true, _lat:r.value.latency};
      S.engines[srv.id]  = r.value.engines;
    } else {
      S.overview[srv.id] = {_ok:false, _err:r.reason.message};
      S.engines[srv.id]  = [];
    }
  });
  const ok = Object.values(S.overview).filter(o=>o._ok).length;
  const p = q("#fleetConn");
  p.textContent = servers.length ? `${ok}/${servers.length} server terhubung` : "Belum ada server";
  p.className = "fleet-pill " + (!servers.length ? "" : ok===servers.length ? "ok" : "bad");
  renderOverview(); renderServers(); renderEngines(); fillSelects();
}

function renderOverview(){
  const a = {eng:0,on:0,cam:0,camOn:0,ai:0,spool:0,ev:0};
  Object.values(S.overview).forEach(o => { if(!o._ok) return;
    a.eng += o.engines_total||0; a.on += o.engines_online||0;
    a.cam += o.cameras_total||0; a.camOn += o.cameras_online||0;
    a.ai += o.ai_enabled||0; a.spool += o.spool_pending_total||0; a.ev += o.events_24h||0; });
  const off = a.eng - a.on;
  q("#fleetKpis").innerHTML = `
    <div class="fleet-kpi"><div class="l">Server Regional</div><div class="v blue">${servers.length}</div>
      <div class="s">${Object.values(S.overview).filter(o=>o._ok).length} terhubung</div></div>
    <div class="fleet-kpi"><div class="l">AI Engine</div><div class="v ${off?"amber":"green"}">${a.on}/${a.eng}</div>
      <div class="s">${off ? off+" offline" : "semua online"}</div></div>
    <div class="fleet-kpi"><div class="l">Kamera</div><div class="v ${a.cam-a.camOn?"amber":"green"}">${a.camOn}/${a.cam}</div>
      <div class="s">${a.ai} dengan AI aktif</div></div>
    <div class="fleet-kpi"><div class="l">Event 24 Jam</div><div class="v">${a.ev.toLocaleString("id-ID")}</div>
      <div class="s">seluruh wilayah</div></div>
    <div class="fleet-kpi"><div class="l">Antrean Tertahan</div>
      <div class="v ${a.spool>100?"red":a.spool?"amber":"green"}">${a.spool.toLocaleString("id-ID")}</div>
      <div class="s">store &amp; forward di edge</div></div>`;

  q("#fleetServerStatus").innerHTML = servers.length ? servers.map(srv => {
    const o = S.overview[srv.id]||{}, engines = S.engines[srv.id]||[];
    const bad = engines.filter(e => !e.reachable);
    return `<div class="fleet-card">
      <div class="fleet-chead"><div class="fleet-dot ${o._ok?"ok":"bad"}"></div>
        <div><div class="nm">${esc(srv.name)}</div><div class="sub">${esc(srv.url)}</div></div>
        <div class="act"><span class="fleet-badge">${o._ok ? o._lat+" ms" : "offline"}</span></div></div>
      ${o._ok ? `<div class="fleet-metrics">
        <div class="fleet-metric"><div class="ml">Engine</div><div class="mv">${o.engines_online}/${o.engines_total}</div></div>
        <div class="fleet-metric"><div class="ml">Kamera</div><div class="mv">${o.cameras_online}/${o.cameras_total}</div></div>
        <div class="fleet-metric"><div class="ml">AI aktif</div><div class="mv">${o.ai_enabled}</div></div>
        <div class="fleet-metric"><div class="ml">Event 24j</div><div class="mv">${o.events_24h}</div></div></div>
        ${bad.length ? `<div class="fleet-camlist">${bad.slice(0,4).map(e=>
          `<div class="fleet-camrow"><div class="fleet-dot bad"></div><div class="cn">${esc(e.site_name||e.engine_id)}</div>
           <span class="fleet-badge" style="color:#FF4D5E">${esc((e.error||"tidak terjangkau").slice(0,28))}</span></div>`).join("")}
          ${bad.length>4?`<div class="fleet-camrow" style="color:#8195B4">+${bad.length-4} engine lain bermasalah</div>`:""}</div>`
        : `<div class="fleet-camlist" style="color:#8195B4;font-size:12px">Semua AI Engine terjangkau.</div>`}`
      : `<div style="color:#FF4D5E;font-size:12.5px">${esc(o._err||"Tidak dapat dihubungi")}</div>`}
    </div>`; }).join("")
    : `<div class="fleet-empty">Belum ada server regional. Buka tab <b>Server Regional</b> untuk menambahkan.</div>`;
}

function renderServers(){
  q("#fleetServerEmpty").style.display = servers.length ? "none" : "block";
  q("#fleetServerTable").innerHTML = servers.map((srv,i) => {
    const o = S.overview[srv.id]||{};
    return `<tr>
      <td><span class="fleet-dot ${o._ok?"ok":"bad"}" style="display:inline-block"></span></td>
      <td><b>${esc(srv.name)}</b></td><td>${esc(srv.url)}</td>
      <td>${o._ok?`${o.engines_online}/${o.engines_total}`:"-"}</td>
      <td>${o._ok?`${o.cameras_online}/${o.cameras_total}`:"-"}</td>
      <td>${o._ok?o._lat+" ms":esc((o._err||"").slice(0,32))}</td>
      <td><button class="btn btn-ghost" data-editsrv="${i}" style="padding:4px 10px;font-size:11.5px">Ubah</button></td>
    </tr>`; }).join("");
  qa("[data-editsrv]").forEach(b => b.addEventListener("click", () => openServer(+b.dataset.editsrv)));
}

function fillSelects(){
  const opts = servers.map(s=>`<option value="${esc(s.id)}">${esc(s.name)}</option>`).join("");
  [["#fleetEngineFilter",1],["#fe_server",0],["#fleetEvServer",1]].forEach(([sel,all])=>{
    const el = q(sel); if(!el) return;
    const cur = el.value;
    el.innerHTML = (all?`<option value="">Semua server</option>`:"") + opts;
    if(cur) el.value = cur;
  });
}

/* ───── AI Engine ───── */
function renderEngines(){
  const f = q("#fleetEngineFilter").value;
  const cards = [];
  servers.forEach(srv => { if(f && srv.id !== f) return;
    (S.engines[srv.id]||[]).forEach(e => cards.push({srv,e})); });

  q("#fleetEngineGrid").innerHTML = cards.length ? cards.map(({srv,e})=>{
    const t = e.telemetry||{}, cams = t.cameras||[];
    const dot = !e.enabled ? "warn" : e.reachable ? "ok" : "bad";
    return `<div class="fleet-card">
      <div class="fleet-chead"><div class="fleet-dot ${dot}"></div>
        <div><div class="nm">${esc(e.site_name||e.engine_id)}</div>
          <div class="sub">${esc(e.engine_id)} · ${esc(srv.name)}</div></div>
        <div class="act"><button class="btn btn-ghost" data-editeng="${esc(srv.id)}|${esc(e.engine_id)}"
          style="padding:4px 10px;font-size:11.5px">Kelola</button></div></div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:9px;">
        <span class="fleet-badge">${esc(e.hw_model||"modul?")}</span>
        <span class="fleet-badge ${t.decoder==="nvdec"?"hw":""}">${esc(t.decoder||"-")}</span>
        <span class="fleet-badge ${t.engine_backend==="tensorrt"?"hw":""}">${esc(t.engine_backend||"-")}</span>
        ${t.spool_pending?`<span class="fleet-badge" style="color:#F5A623;border-color:#6A5219">antre ${t.spool_pending}</span>`:""}
      </div>
      ${e.reachable ? `<div class="fleet-metrics">
        <div class="fleet-metric"><div class="ml">GPU</div><div class="mv">${(t.gpu_pct??0).toFixed(0)}%</div></div>
        <div class="fleet-metric"><div class="ml">CPU</div><div class="mv">${(t.cpu_pct??0).toFixed(0)}%</div></div>
        <div class="fleet-metric"><div class="ml">Suhu</div><div class="mv" style="color:${(t.temp_c||0)>80?"#FF4D5E":"inherit"}">${(t.temp_c??0).toFixed(0)}&deg;</div></div>
        <div class="fleet-metric"><div class="ml">Disk</div><div class="mv" style="color:${(t.disk_pct||0)>85?"#FF4D5E":"inherit"}">${(t.disk_pct??0).toFixed(0)}%</div></div></div>
      <div class="fleet-camlist">${cams.length ? cams.slice(0,6).map(c=>`
        <div class="fleet-camrow"><div class="fleet-dot ${c.online?"ok":"bad"}"></div>
          <div class="cn">${esc(c.name||c.camera_id)}</div>
          ${c.ai_enabled?`<span class="fleet-badge ai">AI ${(c.infer_fps??0).toFixed(1)}</span>`:""}
          ${c.recording?`<span class="fleet-badge rec">REC</span>`:""}
          <span class="fleet-badge">${(c.capture_fps??0).toFixed(0)} fps</span></div>`).join("")
        : `<div style="color:#8195B4;font-size:12px">Belum ada kamera.</div>`}</div>`
      : `<div style="color:#FF4D5E;font-size:12.5px">${esc(e.error||"Tidak terjangkau")} · ${ago(e.last_heartbeat)}</div>`}
    </div>`; }).join("")
    : `<div class="fleet-empty">Belum ada AI Engine terdaftar.</div>`;

  qa("[data-editeng]").forEach(b => b.addEventListener("click", () => {
    const [sid, eid] = b.dataset.editeng.split("|");
    openEngine(sid, eid);
  }));
}

/* ───── Modal server ───── */
function openServer(i){
  S.editSrv = i;
  const s = i>=0 ? servers[i] : {name:"",id:"",url:"",key:""};
  q("#fleetServerTitle").textContent = i>=0 ? "Ubah Server Regional" : "Tambah Server Regional";
  q("#fs_name").value=s.name; q("#fs_id").value=s.id; q("#fs_url").value=s.url; q("#fs_key").value=s.key||"";
  q("#fs_del").style.display = i>=0 ? "inline-flex" : "none";
  q("#fleetServerOv").classList.add("active");
}
q("#fleetAddServer").addEventListener("click", ()=>openServer(-1));
q("#fs_save").addEventListener("click", ()=>{
  const s = {name:q("#fs_name").value.trim(), id:q("#fs_id").value.trim(),
             url:q("#fs_url").value.trim(), key:q("#fs_key").value};
  if(!s.name||!s.id||!s.url) return msg("#fs_msg", false, "Nama, Region ID, dan Base URL wajib diisi.");
  if(!/^https?:\/\//.test(s.url)) return msg("#fs_msg", false, "Base URL harus diawali http:// atau https://");
  if(S.editSrv>=0) servers[S.editSrv]=s;
  else if(servers.some(x=>x.id===s.id)) return msg("#fs_msg", false, "Region ID sudah dipakai.");
  else servers.push(s);
  saveServers(); msg("#fs_msg", true, "Tersimpan.");
  setTimeout(()=>{ q("#fleetServerOv").classList.remove("active"); refresh(); }, 450);
});
q("#fs_del").addEventListener("click", ()=>{
  if(S.editSrv<0) return;
  if(!confirm(`Hapus "${servers[S.editSrv].name}" dari daftar monitor ini?\n\nData di server itu sendiri tidak terhapus.`)) return;
  servers.splice(S.editSrv,1); saveServers();
  q("#fleetServerOv").classList.remove("active"); refresh();
});
q("#fs_test").addEventListener("click", async ()=>{
  const s = {url:q("#fs_url").value.trim(), key:q("#fs_key").value};
  if(!s.url) return msg("#fs_msg", false, "Isi Base URL dulu.");
  try { const t0=performance.now(); const r = await call(s,"/api/region");
    msg("#fs_msg", true, `Terhubung ke ${r.region_name} — ${r.engines_total} engine, ${Math.round(performance.now()-t0)} ms.`);
  } catch(e){ msg("#fs_msg", false, "Gagal: "+e.message); }
});
q("#fleetExport").addEventListener("click", ()=>{
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(servers,null,2)],{type:"application/json"}));
  a.download = "enpidix-servers.json"; a.click();
});
q("#fleetImport").addEventListener("click", ()=>{
  const i = document.createElement("input"); i.type="file"; i.accept="application/json";
  i.onchange = async ()=>{ try{ const l = JSON.parse(await i.files[0].text());
    if(!Array.isArray(l)) throw new Error("Format bukan array");
    servers = l; saveServers(); refresh(); }catch(e){ alert("Import gagal: "+e.message); } };
  i.click();
});

/* ───── Modal AI Engine ───── */
function openEngine(sid, eid){
  const e = eid ? (S.engines[sid]||[]).find(x=>x.engine_id===eid) : null;
  S.editEng = e ? {sid, eid} : null;
  q("#fleetEngineTitle").textContent = e ? "Kelola AI Engine" : "Tambah AI Engine";
  q("#fe_server").value = sid || (servers[0]||{}).id || "";
  q("#fe_server").disabled = !!e;
  q("#fe_id").value = e?.engine_id||""; q("#fe_site").value = e?.site_id||"";
  q("#fe_sitename").value = e?.site_name||""; q("#fe_host").value = e?.host||"";
  q("#fe_port").value = e?.port||8000; q("#fe_scheme").value = e?.scheme||"http";
  q("#fe_hw").value = e?.hw_model || "Jetson Orin NX 16GB";
  q("#fe_notes").value = e?.notes||""; q("#fe_key").value = "";
  q("#fe_del").style.display = e ? "inline-flex" : "none";
  q("#fe_open").style.display = e?.host ? "inline-flex" : "none";
  q("#fleetEngineOv").classList.add("active");
}
q("#fleetAddEngine").addEventListener("click", ()=>{
  if(!servers.length) return alert("Tambahkan server regional dulu.");
  openEngine(servers[0].id, null);
});
q("#fleetEngineFilter").addEventListener("change", renderEngines);

q("#fe_save").addEventListener("click", async ()=>{
  const srv = srvById(q("#fe_server").value);
  if(!srv) return msg("#fe_msg", false, "Pilih server regional.");
  const body = {
    engine_id:q("#fe_id").value.trim(), site_id:q("#fe_site").value.trim(),
    site_name:q("#fe_sitename").value.trim(), host:q("#fe_host").value.trim(),
    port:parseInt(q("#fe_port").value)||8000, scheme:q("#fe_scheme").value,
    api_key:q("#fe_key").value, hw_model:q("#fe_hw").value,
    notes:q("#fe_notes").value.trim(), enabled:true };
  if(!body.engine_id||!body.site_id||!body.host)
    return msg("#fe_msg", false, "Engine ID, Site ID, dan Host wajib diisi.");
  try { await call(srv,"/api/engines",{method:"POST",body:JSON.stringify(body)});
    msg("#fe_msg", true, "Tersimpan.");
    setTimeout(()=>{ q("#fleetEngineOv").classList.remove("active"); refresh(); }, 450);
  } catch(e){ msg("#fe_msg", false, "Gagal: "+e.message); }
});
q("#fe_test").addEventListener("click", async ()=>{
  const srv = srvById(q("#fe_server").value), id = q("#fe_id").value.trim();
  if(!srv||!id) return msg("#fe_msg", false, "Simpan dulu sebelum tes koneksi.");
  try { const r = await call(srv,`/api/engines/${encodeURIComponent(id)}/test`,{method:"POST"});
    msg("#fe_msg", r.reachable, r.reachable ? `Terjangkau — ${r.detail||"OK"} (${r.latency_ms} ms)`
                                            : `Tidak terjangkau: ${r.detail}`);
  } catch(e){ msg("#fe_msg", false, "Gagal: "+e.message); }
});
q("#fe_open").addEventListener("click", ()=>{
  const h = q("#fe_host").value.trim(), p = q("#fe_port").value, s = q("#fe_scheme").value;
  if(h) window.open(`${s}://${h}:${p}/`, "_blank");
});
q("#fe_del").addEventListener("click", async ()=>{
  if(!S.editEng) return;
  if(!confirm(`Hapus AI Engine "${S.editEng.eid}" dari registry?\n\nPerangkat di lapangan tetap berjalan — hanya pendaftarannya yang dihapus.`)) return;
  try { await call(srvById(S.editEng.sid), `/api/engines/${encodeURIComponent(S.editEng.eid)}`, {method:"DELETE"});
    q("#fleetEngineOv").classList.remove("active"); refresh();
  } catch(e){ msg("#fe_msg", false, "Gagal: "+e.message); }
});

/* ───── Event log ───── */
let evTimer = null;
async function loadEvents(){
  const f = q("#fleetEvServer").value, kind = q("#fleetEvKind").value;
  const targets = f ? servers.filter(s=>s.id===f) : servers;
  const rows = [];
  await Promise.allSettled(targets.map(async srv=>{
    const p = new URLSearchParams({limit:"120"}); if(kind) p.set("kind",kind);
    (await call(srv,"/api/events?"+p)).forEach(e=>rows.push({...e,_srv:srv.name}));
  }));
  rows.sort((a,b)=>b.received_at-a.received_at);
  q("#fleetEventEmpty").style.display = rows.length ? "none" : "block";
  q("#fleetEventTable").innerHTML = rows.slice(0,200).map(e=>{
    const c = e.kind==="engine_error" ? "#FF4D5E" : e.kind==="fire_smoke" ? "#F5A623"
            : e.kind==="line_crossing" ? "#3E7BFA" : "#8195B4";
    return `<tr><td>${fmtTime(e.ts)}</td>
      <td>${esc(e.site_id)}<div style="font-size:10.5px;color:#8195B4">${esc(e._srv)}</div></td>
      <td>${esc(e.camera_id)}</td>
      <td><span class="fleet-badge" style="color:${c}">${esc(e.kind)}</span></td>
      <td>${esc(e.label)}</td>
      <td>${e.confidence?(e.confidence*100).toFixed(0)+"%":"-"}</td></tr>`;
  }).join("");
}
q("#fleetEvServer").addEventListener("change", loadEvents);
q("#fleetEvKind").addEventListener("change", loadEvents);
q("#fleetEvAuto").addEventListener("change", setupEvTimer);
function setupEvTimer(){
  clearInterval(evTimer);
  if(q("#fleetEvAuto").checked) evTimer = setInterval(()=>{
    if(q("#fv-events").classList.contains("active") && document.body.classList.contains("scope-fleet")) loadEvents();
  }, 10000);
}
q("#fleetRefresh").addEventListener("click", refresh);

/* ═══════ Settings → tab Fleet (konfigurasi site INI) ═══════ */
const API_BASE = (typeof API !== "undefined") ? API : "";

async function loadFleetCfg(){
  try {
    const c = await (await fetch(API_BASE+"/api/fleet/config",{credentials:"include"})).json();
    q("#fl_engine").value=c.engine_id||""; q("#fl_site").value=c.site_id||"";
    q("#fl_sitename").value=c.site_name||""; q("#fl_url").value=c.regional_url||"";
    q("#fl_key").value = c.regional_key ? "••••••" : "";
    q("#fl_hw").value = c.hw_model||"";
    q("#fl_enabled").checked = !!c.enabled;
    q("#fl_nvdec").checked = !!c.patch_nvdec;
    q("#fl_copy").checked  = !!c.patch_streamcopy;
    q("#fl_par").checked   = !!c.patch_parallel_ai;
    q("#fl_slots").value   = c.ai_slots || 3;
  } catch(e){ /* modul fleet belum dipasang di server ini */ }
}

async function saveFleetCfg(){
  const body = {
    engine_id:q("#fl_engine").value.trim(), site_id:q("#fl_site").value.trim(),
    site_name:q("#fl_sitename").value.trim(), regional_url:q("#fl_url").value.trim(),
    regional_key:q("#fl_key").value, hw_model:q("#fl_hw").value,
    enabled:q("#fl_enabled").checked?1:0, patch_nvdec:q("#fl_nvdec").checked?1:0,
    patch_streamcopy:q("#fl_copy").checked?1:0, patch_parallel_ai:q("#fl_par").checked?1:0,
    ai_slots:parseInt(q("#fl_slots").value)||3 };
  try {
    const r = await (await fetch(API_BASE+"/api/fleet/config",{
      method:"POST", credentials:"include",
      headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)})).json();
    const p = r.patches||{};
    const set = (sel,v)=>{ const el=q(sel); if(!el) return;
      el.textContent = v||"—";
      el.className = "fleet-state" + (/gagal/i.test(v)?" err":/nonaktif/i.test(v)?" off":""); };
    set("#fl_nvdec_state", p.nvdec); set("#fl_copy_state", p.stream_copy); set("#fl_par_state", p.parallel_ai);
    msg("#fl_msg", true, "Konfigurasi tersimpan dan patch diterapkan.");
    loadFleetStatus();
  } catch(e){ msg("#fl_msg", false, "Gagal: "+e.message); }
}

async function loadFleetStatus(){
  const el = q("#fl_status"); if(!el) return;
  try {
    const s = await (await fetch(API_BASE+"/api/fleet/status",{credentials:"include"})).json();
    const t = s.telemetry||{};
    el.innerHTML = `
      Status      : ${s.enabled ? (s.connected?'<span style="color:#2FE6A6">terhubung</span>'
                                             :'<span style="color:#FF4D5E">terputus</span>')
                                : '<span style="color:#8195B4">nonaktif</span>'}<br>
      Regional    : ${esc(s.regional_url||"(belum diset)")}<br>
      Engine ID   : ${esc(s.engine_id||"(belum diset)")}<br>
      Antrean     : ${s.spool_pending} event menunggu kirim<br>
      Terkirim    : ${s.sent_total} event sesi ini<br>
      Terakhir OK : ${s.last_success?ago(s.last_success):"belum pernah"}<br>
      Decoder     : ${esc((s.patches||{}).decoder||"cpu")}<br>
      Perangkat   : ${esc(t.model||"tidak terdeteksi")}${t.gpu_pct?` · GPU ${t.gpu_pct}% · ${t.temp_c}°C`:""}
      ${s.last_error?`<br><span style="color:#FF4D5E">Error: ${esc(s.last_error)}</span>`:""}`;
  } catch(e){
    el.innerHTML = '<span style="color:#8195B4">Modul fleet belum terpasang di server ini. '
      + 'Tambahkan <b>enpidix_fleet.py</b> dan tiga baris pemasangannya di server.py.</span>';
  }
}

const on = (sel, ev, fn) => { const el = q(sel); if(el) el.addEventListener(ev, fn); };
on("#fl_save","click", saveFleetCfg);
on("#fl_test","click", async ()=>{
  try { const r = await (await fetch(API_BASE+"/api/fleet/test",{method:"POST",credentials:"include"})).json();
    msg("#fl_msg", r.reachable, r.reachable?`Terhubung (${r.latency_ms} ms)`:`Gagal: ${r.detail}`);
  } catch(e){ msg("#fl_msg", false, "Gagal: "+e.message); }
});
on("#fl_flush","click", async ()=>{
  try { const r = await (await fetch(API_BASE+"/api/fleet/flush",{method:"POST",credentials:"include"})).json();
    msg("#fl_msg", true, `Antrean tersisa: ${r.spool_pending}`); loadFleetStatus();
  } catch(e){ msg("#fl_msg", false, "Gagal: "+e.message); }
});
qa('.settings-tab[data-tab="fleet"]').forEach(t => t.addEventListener("click", ()=>{
  loadFleetCfg(); loadFleetStatus();
}));

/* ───── Boot ───── */
fillSelects(); setupEvTimer(); loadFleetStatus();
setInterval(()=>{ if(document.body.classList.contains("scope-fleet")) refresh(); }, 15000);
setInterval(loadFleetStatus, 30000);

})();
