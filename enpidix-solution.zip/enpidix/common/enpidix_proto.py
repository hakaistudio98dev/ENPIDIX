"""
ENPIDIX — Kontrak data bersama antar tier.
==========================================
File ini di-copy (bukan di-import lintas mesin) ke edge-jetson/ dan regional-server/
supaya tiap tier tetap bisa berdiri sendiri di jaringan tertutup.

Aturan arah data:
  EDGE (Jetson)  --push-->  REGIONAL      : event, metadata, snapshot kecil, heartbeat
  REGIONAL       --pull-->  EDGE          : health, konfigurasi, MJPEG on-demand
  CLIENT         --pull-->  REGIONAL      : semuanya (client TIDAK pernah kontak Jetson langsung)

Video penuh TIDAK PERNAH di-push. Hanya ditarik saat operator membuka live view.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

PROTO_VERSION = "1.0"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─────────────────────────────────────────────────────────────
# Event: satu kejadian yang terdeteksi AI di edge
# ─────────────────────────────────────────────────────────────

EventKind = Literal[
    "object_detected",
    "line_crossing",
    "zone_intrusion",
    "fire_smoke",
    "people_count",
    "anpr",
    "camera_offline",
    "camera_online",
    "engine_started",
    "engine_error",
]


class Event(BaseModel):
    event_id: str = Field(..., description="UUID4, dibuat di edge — dipakai untuk dedupe di regional")
    site_id: str
    engine_id: str = Field(..., description="ID Jetson yang menghasilkan event")
    camera_id: str
    kind: EventKind
    label: str = Field("", description="Kelas objek / plat nomor / nama zona")
    confidence: float = 0.0
    ts: str = Field(default_factory=utcnow, description="Waktu kejadian di edge, ISO8601 UTC")
    bbox: Optional[list[float]] = Field(None, description="[x1,y1,x2,y2] ternormalisasi 0-1")
    snapshot_b64: Optional[str] = Field(None, description="JPEG base64, maks ~120 KB. None = tidak dikirim.")
    meta: dict[str, Any] = Field(default_factory=dict)


class EventBatch(BaseModel):
    """Edge mengirim batch, bukan satu-satu — hemat overhead TLS di link lemah."""
    proto: str = PROTO_VERSION
    engine_id: str
    site_id: str
    sent_at: str = Field(default_factory=utcnow)
    events: list[Event]


# ─────────────────────────────────────────────────────────────
# Heartbeat: kabar sehat + telemetri ringan
# ─────────────────────────────────────────────────────────────

class CameraStat(BaseModel):
    camera_id: str
    name: str = ""
    online: bool = False
    ai_enabled: bool = False
    capture_fps: float = 0.0
    infer_fps: float = 0.0
    last_frame_age_sec: float = -1.0
    recording: bool = False


class Heartbeat(BaseModel):
    proto: str = PROTO_VERSION
    engine_id: str
    site_id: str
    ts: str = Field(default_factory=utcnow)

    model: str = Field("", description="Model Jetson, mis. 'Orin NX 16GB'")
    jetpack: str = ""
    uptime_sec: float = 0.0

    cpu_pct: float = 0.0
    mem_pct: float = 0.0
    disk_pct: float = 0.0
    gpu_pct: float = 0.0
    temp_c: float = 0.0
    power_w: float = 0.0

    engine_backend: str = Field("", description="'tensorrt' | 'pytorch' | 'none'")
    decoder: str = Field("", description="'nvdec' | 'cpu'")

    spool_pending: int = Field(0, description="Jumlah event yang belum terkirim (store & forward)")
    cameras: list[CameraStat] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# Konfigurasi kamera & AI — dikirim REGIONAL -> EDGE
# ─────────────────────────────────────────────────────────────

class AIConfig(BaseModel):
    enabled: bool = False
    tasks: list[str] = Field(default_factory=list, description="detect | count | fire | anpr")
    classes: list[str] = Field(default_factory=lambda: ["person"])
    conf: float = 0.45
    infer_fps: float = Field(5.0, description="Target FPS inferensi. Bukan FPS stream.")
    imgsz: int = 640
    count_shape: Literal["line", "polygon", "none"] = "none"
    count_line: list[float] = Field(default_factory=lambda: [0.1, 0.5, 0.9, 0.5])
    count_polygon: list[list[float]] = Field(default_factory=list)
    confirm_frames: int = Field(3, description="Anti-flicker: status baru berubah setelah N frame beruntun")


class CameraConfig(BaseModel):
    camera_id: str
    name: str = ""
    # PENTING: main_url untuk rekaman (stream copy), sub_url untuk AI.
    # Jangan pernah pakai main_url untuk inferensi.
    main_url: str = Field(..., description="RTSP main stream — dipakai recorder (-c copy)")
    sub_url: str = Field("", description="RTSP sub stream — dipakai AI. Kosong = pakai main (tidak disarankan)")
    enabled: bool = True
    record: bool = False
    ai: AIConfig = Field(default_factory=AIConfig)


class EngineConfig(BaseModel):
    """Konfigurasi tingkat perangkat AI Engine (Jetson)."""
    engine_id: str
    site_id: str
    site_name: str = ""
    model_path: str = Field("models/yolov8s.engine", description=".engine (TensorRT) atau .pt (fallback)")
    precision: Literal["int8", "fp16", "fp32"] = "int8"
    decoder: Literal["nvdec", "cpu"] = "nvdec"
    max_cameras: int = 6
    record_dir: str = "/var/lib/enpidix/recordings"
    record_segment_sec: int = 600
    retention_days: int = 7
    forward_interval_sec: float = 5.0
    snapshot_max_kb: int = 120
    cameras: list[CameraConfig] = Field(default_factory=list)


# ─────────────────────────────────────────────────────────────
# Registry di REGIONAL: daftar AI Engine yang dia kelola
# ─────────────────────────────────────────────────────────────

class EngineRegistration(BaseModel):
    engine_id: str
    site_id: str
    site_name: str = ""
    host: str = Field(..., description="IP/hostname Jetson di jaringan site atau via VPN")
    port: int = 8100
    api_key: str = Field("", description="Shared secret untuk memanggil API Jetson")
    scheme: Literal["http", "https"] = "http"
    hw_model: str = Field("Jetson Orin NX 16GB", description="Tipe modul, untuk inventaris")
    notes: str = ""
    enabled: bool = True

    @property
    def base_url(self) -> str:
        return f"{self.scheme}://{self.host}:{self.port}"


class Ack(BaseModel):
    status: str = "ok"
    accepted: int = 0
    duplicates: int = 0
    message: str = ""
