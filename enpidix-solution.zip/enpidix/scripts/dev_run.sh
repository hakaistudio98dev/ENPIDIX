#!/usr/bin/env bash
# Jalankan regional server + dashboard lokal untuk pengembangan.
# Jetson tidak wajib ada: registry & event log tetap bisa diuji.
set -e
cd "$(dirname "$0")/.."

export ENPIDIX_REGION_ID=${ENPIDIX_REGION_ID:-regional-dev}
export ENPIDIX_REGION_NAME=${ENPIDIX_REGION_NAME:-"Regional Dev"}
export ENPIDIX_REGIONAL_DB=${ENPIDIX_REGIONAL_DB:-./data/regional.db}
export ENPIDIX_SNAPSHOT_DIR=${ENPIDIX_SNAPSHOT_DIR:-./data/snapshots}
export ENPIDIX_REGIONAL_API_KEY=${ENPIDIX_REGIONAL_API_KEY:-dev-ingest}
export ENPIDIX_CLIENT_API_KEY=${ENPIDIX_CLIENT_API_KEY:-dev-client}
mkdir -p ./data

echo "Regional  : http://localhost:8200   (client key: $ENPIDIX_CLIENT_API_KEY)"
echo "Dashboard : http://localhost:8300/dashboard.html"
echo

( cd client-monitor && python3 -m http.server 8300 >/dev/null 2>&1 ) &
trap 'kill 0' EXIT
cd regional-server && exec uvicorn regional_main:app --host 0.0.0.0 --port 8200 --reload
