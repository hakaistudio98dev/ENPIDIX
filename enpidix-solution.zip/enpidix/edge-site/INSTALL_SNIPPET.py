# ══════════════════════════════════════════════════════════
# TIGA BARIS PEMASANGAN DI server.py
# ══════════════════════════════════════════════════════════

# ── (1) Setelah `app = FastAPI(...)` (sekitar baris 139) ──
import enpidix_fleet

# ── (2) Tepat SEBELUM `if __name__ == "__main__":` ──
#      Harus di akhir supaya semua kelas (CameraWorker, CameraRecorder)
#      dan fungsi (kirim_event_ke_nx) sudah terdefinisi saat di-patch.
enpidix_fleet.install(app, globals())

# ── (3) Di dalam handler shutdown yang sudah ada (sekitar baris 2426) ──
@app.on_event("shutdown")
def _shutdown():
    # ... kode shutdown Anda yang sudah ada ...
    enpidix_fleet.shutdown()
