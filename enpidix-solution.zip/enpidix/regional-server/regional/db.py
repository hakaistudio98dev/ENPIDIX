"""
Penyimpanan regional.

SQLite dipakai default supaya satu regional bisa langsung jalan tanpa DBA.
Untuk 125 site × 3 kamera, aktifkan PostgreSQL + TimescaleDB lewat env
`ENPIDIX_PG_DSN` — tabel event akan tumbuh jutaan baris per bulan dan SQLite
akan mulai tersendat di sekitar 5–10 juta baris.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import time
from pathlib import Path

DB_PATH = Path(os.environ.get("ENPIDIX_REGIONAL_DB", "/var/lib/enpidix/regional.db"))
SNAPSHOT_DIR = Path(os.environ.get("ENPIDIX_SNAPSHOT_DIR", "/var/lib/enpidix/snapshots"))

_SCHEMA = """
CREATE TABLE IF NOT EXISTS engines (
    engine_id   TEXT PRIMARY KEY,
    site_id     TEXT NOT NULL,
    site_name   TEXT DEFAULT '',
    host        TEXT NOT NULL,
    port        INTEGER NOT NULL DEFAULT 8100,
    scheme      TEXT NOT NULL DEFAULT 'http',
    api_key     TEXT DEFAULT '',
    hw_model    TEXT DEFAULT '',
    notes       TEXT DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    created_at  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS heartbeats (
    engine_id   TEXT PRIMARY KEY,
    received_at REAL NOT NULL,
    payload     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    event_id    TEXT PRIMARY KEY,
    engine_id   TEXT NOT NULL,
    site_id     TEXT NOT NULL,
    camera_id   TEXT NOT NULL,
    kind        TEXT NOT NULL,
    label       TEXT DEFAULT '',
    confidence  REAL DEFAULT 0,
    ts          TEXT NOT NULL,
    received_at REAL NOT NULL,
    snapshot    TEXT DEFAULT '',
    meta        TEXT DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_ev_recv   ON events(received_at DESC);
CREATE INDEX IF NOT EXISTS idx_ev_engine ON events(engine_id, received_at DESC);
CREATE INDEX IF NOT EXISTS idx_ev_kind   ON events(kind, received_at DESC);
"""

_lock = threading.Lock()
_conn: sqlite3.Connection | None = None


def conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        DB_PATH.parent.mkdir(parents=True, exist_ok=True)
        SNAPSHOT_DIR.mkdir(parents=True, exist_ok=True)
        _conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA synchronous=NORMAL")
        _conn.executescript(_SCHEMA)
        _conn.commit()
    return _conn


# ── engines (AI Engine registry) ─────────────────────────────
def list_engines() -> list[dict]:
    with _lock:
        rows = conn().execute("SELECT * FROM engines ORDER BY site_name, engine_id").fetchall()
    return [dict(r) for r in rows]


def get_engine(engine_id: str) -> dict | None:
    with _lock:
        r = conn().execute("SELECT * FROM engines WHERE engine_id=?", (engine_id,)).fetchone()
    return dict(r) if r else None


def upsert_engine(d: dict) -> None:
    with _lock:
        conn().execute(
            """INSERT INTO engines(engine_id, site_id, site_name, host, port, scheme,
                                   api_key, hw_model, notes, enabled, created_at)
               VALUES(:engine_id,:site_id,:site_name,:host,:port,:scheme,
                      :api_key,:hw_model,:notes,:enabled,:created_at)
               ON CONFLICT(engine_id) DO UPDATE SET
                 site_id=excluded.site_id, site_name=excluded.site_name,
                 host=excluded.host, port=excluded.port, scheme=excluded.scheme,
                 api_key=excluded.api_key, hw_model=excluded.hw_model,
                 notes=excluded.notes, enabled=excluded.enabled""",
            {**d, "created_at": d.get("created_at", time.time())},
        )
        conn().commit()


def delete_engine(engine_id: str) -> None:
    with _lock:
        c = conn()
        c.execute("DELETE FROM engines WHERE engine_id=?", (engine_id,))
        c.execute("DELETE FROM heartbeats WHERE engine_id=?", (engine_id,))
        c.commit()


# ── heartbeat ────────────────────────────────────────────────
def save_heartbeat(engine_id: str, payload: dict) -> None:
    with _lock:
        conn().execute(
            "INSERT INTO heartbeats(engine_id, received_at, payload) VALUES(?,?,?) "
            "ON CONFLICT(engine_id) DO UPDATE SET received_at=excluded.received_at, payload=excluded.payload",
            (engine_id, time.time(), json.dumps(payload)),
        )
        conn().commit()


def get_heartbeats() -> dict[str, dict]:
    with _lock:
        rows = conn().execute("SELECT * FROM heartbeats").fetchall()
    return {
        r["engine_id"]: {"received_at": r["received_at"], **json.loads(r["payload"])}
        for r in rows
    }


# ── events ───────────────────────────────────────────────────
def insert_events(events: list[dict]) -> tuple[int, int]:
    """Dedupe berbasis event_id — edge boleh kirim ulang batch yang gagal di-ACK."""
    accepted = dup = 0
    with _lock:
        c = conn()
        for e in events:
            snap_ref = ""
            if e.get("snapshot_b64"):
                snap_ref = _write_snapshot(e["event_id"], e["snapshot_b64"])
            try:
                c.execute(
                    """INSERT INTO events(event_id, engine_id, site_id, camera_id, kind, label,
                                          confidence, ts, received_at, snapshot, meta)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        e["event_id"], e["engine_id"], e["site_id"], e["camera_id"], e["kind"],
                        e.get("label", ""), e.get("confidence", 0.0), e["ts"], time.time(),
                        snap_ref, json.dumps(e.get("meta", {})),
                    ),
                )
                accepted += 1
            except sqlite3.IntegrityError:
                dup += 1
        c.commit()
    return accepted, dup


def _write_snapshot(event_id: str, b64: str) -> str:
    """Snapshot ditulis ke disk, bukan ke kolom BLOB — DB tetap ramping dan cepat."""
    import base64

    path = SNAPSHOT_DIR / f"{event_id}.jpg"
    try:
        path.write_bytes(base64.b64decode(b64))
        return str(path)
    except Exception:  # noqa: BLE001
        return ""


def query_events(limit: int = 100, engine_id: str = "", kind: str = "", since: float = 0.0) -> list[dict]:
    sql = "SELECT * FROM events WHERE 1=1"
    args: list = []
    if engine_id:
        sql += " AND engine_id=?"
        args.append(engine_id)
    if kind:
        sql += " AND kind=?"
        args.append(kind)
    if since:
        sql += " AND received_at>?"
        args.append(since)
    sql += " ORDER BY received_at DESC LIMIT ?"
    args.append(min(limit, 1000))

    with _lock:
        rows = conn().execute(sql, args).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["meta"] = json.loads(d.get("meta") or "{}")
        d["has_snapshot"] = bool(d.pop("snapshot", ""))
        out.append(d)
    return out


def purge_events(days: int) -> int:
    cutoff = time.time() - days * 86400
    with _lock:
        cur = conn().execute("DELETE FROM events WHERE received_at < ?", (cutoff,))
        conn().commit()
        return cur.rowcount
