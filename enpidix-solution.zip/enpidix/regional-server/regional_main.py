"""
ENPIDIX Regional Server — Tier 2
================================
Satu instance per wilayah (target: 125 site / 375 kamera).

Perannya BUKAN mengumpulkan video. Kalau 375 stream RTSP ditarik ke sini,
butuh ~1,9 Gbps terus-menerus. Dengan pola edge-first ini, trafik tetap
sekitar 50 Mbps per regional karena yang naik hanya event, metadata, dan
snapshot. Video penuh hanya ditarik saat operator benar-benar menonton —
lewat endpoint proxy di bawah.

Jalankan:
    ENPIDIX_REGIONAL_API_KEY=rahasia-regional \\
    ENPIDIX_CLIENT_API_KEY=rahasia-client \\
    uvicorn regional_main:app --host 0.0.0.0 --port 8200
"""

from __future__ import annotations

import os
import threading
import time
from contextlib import asynccontextmanager

import requests
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from regional import db
from regional.proto import Ack, EngineRegistration, EventBatch, Heartbeat

REGION_ID = os.environ.get("ENPIDIX_REGION_ID", "regional-1")
REGION_NAME = os.environ.get("ENPIDIX_REGION_NAME", "Regional 1")
INGEST_KEY = os.environ.get("ENPIDIX_REGIONAL_API_KEY", "")   # dipakai edge -> regional
CLIENT_KEY = os.environ.get("ENPIDIX_CLIENT_API_KEY", "")      # dipakai dashboard -> regional
EVENT_RETENTION_DAYS = int(os.environ.get("ENPIDIX_EVENT_RETENTION_DAYS", "90"))
POLL_INTERVAL = float(os.environ.get("ENPIDIX_POLL_INTERVAL", "30"))

_health_cache: dict[str, dict] = {}
_stop = threading.Event()


def require_ingest(x_api_key: str = Header(default="")) -> None:
    if INGEST_KEY and x_api_key != INGEST_KEY:
        raise HTTPException(401, "API key ingest tidak valid")


def require_client(x_api_key: str = Header(default="")) -> None:
    if CLIENT_KEY and x_api_key != CLIENT_KEY:
        raise HTTPException(401, "API key client tidak valid")


# ── poller: tarik health dari tiap Jetson ────────────────────
def _poll_loop() -> None:
    while not _stop.is_set():
        for eng in db.list_engines():
            if not eng["enabled"]:
                continue
            url = f"{eng['scheme']}://{eng['host']}:{eng['port']}/api/health"
            try:
                r = requests.get(url, timeout=8)
                _health_cache[eng["engine_id"]] = {
                    "reachable": r.ok,
                    "checked_at": time.time(),
                    "data": r.json() if r.ok else None,
                    "error": "" if r.ok else f"HTTP {r.status_code}",
                }
            except requests.RequestException as exc:
                _health_cache[eng["engine_id"]] = {
                    "reachable": False,
                    "checked_at": time.time(),
                    "data": None,
                    "error": str(exc)[:180],
                }
        _stop.wait(POLL_INTERVAL)


def _purge_loop() -> None:
    while not _stop.is_set():
        _stop.wait(6 * 3600)
        if not _stop.is_set():
            n = db.purge_events(EVENT_RETENTION_DAYS)
            if n:
                print(f"[REGIONAL 🧹] {n} event lama dihapus (retensi {EVENT_RETENTION_DAYS} hari)")


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.conn()
    threading.Thread(target=_poll_loop, name="poller", daemon=True).start()
    threading.Thread(target=_purge_loop, name="purge", daemon=True).start()
    print(f"[REGIONAL ✅] {REGION_NAME} ({REGION_ID}) siap di :8200")
    yield
    _stop.set()


app = FastAPI(title="ENPIDIX Regional Server", version="1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("ENPIDIX_CORS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


# ═════════ INGEST (edge → regional) ═════════
@app.post("/api/ingest/events", response_model=Ack, dependencies=[Depends(require_ingest)])
def ingest_events(batch: EventBatch):
    accepted, dup = db.insert_events([e.model_dump() for e in batch.events])
    return Ack(accepted=accepted, duplicates=dup)


@app.post("/api/ingest/heartbeat", dependencies=[Depends(require_ingest)])
def ingest_heartbeat(hb: Heartbeat):
    db.save_heartbeat(hb.engine_id, hb.model_dump())
    # Site baru yang belum terdaftar tetap dicatat, supaya teknisi lapangan
    # bisa pasang Jetson dulu dan admin melengkapi datanya belakangan.
    if not db.get_engine(hb.engine_id):
        db.upsert_engine({
            "engine_id": hb.engine_id, "site_id": hb.site_id, "site_name": hb.site_id,
            "host": "", "port": 8100, "scheme": "http", "api_key": "",
            "hw_model": hb.model, "notes": "Terdaftar otomatis dari heartbeat", "enabled": 1,
        })
    return {"status": "ok"}


# ═════════ REGISTRY AI ENGINE (dashboard → regional) ═════════
@app.get("/api/region", dependencies=[Depends(require_client)])
def region_info():
    engines = db.list_engines()
    hbs = db.get_heartbeats()
    online = sum(1 for e in engines if _health_cache.get(e["engine_id"], {}).get("reachable"))
    cams = sum(len(hbs.get(e["engine_id"], {}).get("cameras", [])) for e in engines)
    return {
        "region_id": REGION_ID,
        "region_name": REGION_NAME,
        "engines_total": len(engines),
        "engines_online": online,
        "cameras_total": cams,
        "poll_interval_sec": POLL_INTERVAL,
    }


@app.get("/api/engines", dependencies=[Depends(require_client)])
def list_engines():
    hbs = db.get_heartbeats()
    out = []
    for e in db.list_engines():
        hc = _health_cache.get(e["engine_id"], {})
        hb = hbs.get(e["engine_id"], {})
        out.append({
            **{k: v for k, v in e.items() if k != "api_key"},
            "has_api_key": bool(e["api_key"]),
            "reachable": hc.get("reachable", False),
            "last_checked": hc.get("checked_at", 0),
            "error": hc.get("error", ""),
            "telemetry": hc.get("data") or hb or None,
            "last_heartbeat": hb.get("received_at", 0),
        })
    return out


@app.post("/api/engines", dependencies=[Depends(require_client)])
def add_engine(reg: EngineRegistration):
    d = reg.model_dump()
    d["enabled"] = int(reg.enabled)
    # Jangan hapus api_key yang sudah ada kalau field dikirim kosong dari form edit.
    if not d["api_key"]:
        existing = db.get_engine(reg.engine_id)
        if existing:
            d["api_key"] = existing["api_key"]
    db.upsert_engine(d)
    return {"status": "ok", "engine_id": reg.engine_id}


@app.delete("/api/engines/{engine_id}", dependencies=[Depends(require_client)])
def remove_engine(engine_id: str):
    db.delete_engine(engine_id)
    _health_cache.pop(engine_id, None)
    return {"status": "ok"}


class TestResult(BaseModel):
    reachable: bool
    latency_ms: float = 0
    detail: str = ""


@app.post("/api/engines/{engine_id}/test", response_model=TestResult, dependencies=[Depends(require_client)])
def test_engine(engine_id: str):
    eng = db.get_engine(engine_id)
    if not eng:
        raise HTTPException(404, "AI Engine tidak terdaftar")
    if not eng["host"]:
        return TestResult(reachable=False, detail="Host belum diisi")
    t0 = time.time()
    try:
        r = requests.get(f"{eng['scheme']}://{eng['host']}:{eng['port']}/api/health", timeout=8)
        return TestResult(
            reachable=r.ok,
            latency_ms=round((time.time() - t0) * 1000, 1),
            detail=r.json().get("model", "") if r.ok else f"HTTP {r.status_code}",
        )
    except requests.RequestException as exc:
        return TestResult(reachable=False, detail=str(exc)[:200])


# ═════════ PROXY ke Jetson (dashboard tidak pernah kontak Jetson langsung) ═════════
def _edge_target(engine_id: str) -> tuple[str, dict]:
    eng = db.get_engine(engine_id)
    if not eng:
        raise HTTPException(404, "AI Engine tidak terdaftar")
    if not eng["host"]:
        raise HTTPException(400, "Host AI Engine belum diisi")
    return f"{eng['scheme']}://{eng['host']}:{eng['port']}", {"X-API-Key": eng["api_key"] or ""}


@app.api_route("/api/engines/{engine_id}/edge/{path:path}",
               methods=["GET", "POST", "PUT", "DELETE"],
               dependencies=[Depends(require_client)])
async def proxy_edge(engine_id: str, path: str, request: Request):
    """
    Terusan HTTP ke Jetson. Dashboard cukup tahu satu alamat (regional);
    IP Jetson boleh berada di jaringan site atau VPN tanpa perlu diekspos.
    """
    base, headers = _edge_target(engine_id)
    url = f"{base}/api/{path}"
    body = await request.body()
    try:
        r = requests.request(
            request.method, url, headers={**headers, "Content-Type": "application/json"},
            data=body or None, params=dict(request.query_params), timeout=25,
        )
    except requests.RequestException as exc:
        raise HTTPException(502, f"Edge tidak merespons: {exc}") from exc
    try:
        return r.json()
    except ValueError:
        return {"status_code": r.status_code, "text": r.text[:500]}


@app.get("/api/engines/{engine_id}/live/{camera_id}")
def proxy_live(engine_id: str, camera_id: str, key: str = ""):
    """
    Live view on-demand. Query param `key` dipakai karena tag <img> tidak bisa
    mengirim header — inilah satu-satunya jalur video penuh yang melewati WAN,
    dan hanya hidup selama tab terbuka.
    """
    if CLIENT_KEY and key != CLIENT_KEY:
        raise HTTPException(401, "API key client tidak valid")
    base, headers = _edge_target(engine_id)
    try:
        r = requests.get(f"{base}/api/stream/{camera_id}", headers=headers, stream=True, timeout=15)
    except requests.RequestException as exc:
        raise HTTPException(502, f"Edge tidak merespons: {exc}") from exc
    return StreamingResponse(
        r.iter_content(chunk_size=8192),
        media_type=r.headers.get("Content-Type", "multipart/x-mixed-replace; boundary=frame"),
    )


# ═════════ EVENTS ═════════
@app.get("/api/events", dependencies=[Depends(require_client)])
def get_events(limit: int = 100, engine_id: str = "", kind: str = "", since: float = 0):
    return db.query_events(limit=limit, engine_id=engine_id, kind=kind, since=since)


@app.get("/api/overview", dependencies=[Depends(require_client)])
def overview():
    engines = db.list_engines()
    hbs = db.get_heartbeats()
    cams_online = cams_total = ai_on = 0
    spool_pending = 0
    for e in engines:
        hb = _health_cache.get(e["engine_id"], {}).get("data") or hbs.get(e["engine_id"], {})
        spool_pending += hb.get("spool_pending", 0)
        for c in hb.get("cameras", []):
            cams_total += 1
            cams_online += int(c.get("online", False))
            ai_on += int(c.get("ai_enabled", False))
    return {
        "region_id": REGION_ID,
        "region_name": REGION_NAME,
        "engines_total": len(engines),
        "engines_online": sum(1 for e in engines if _health_cache.get(e["engine_id"], {}).get("reachable")),
        "cameras_total": cams_total,
        "cameras_online": cams_online,
        "ai_enabled": ai_on,
        "spool_pending_total": spool_pending,
        "events_24h": len(db.query_events(limit=1000, since=time.time() - 86400)),
    }


@app.get("/health")
def health():
    return {"status": "ok", "region": REGION_ID, "ts": time.time()}
